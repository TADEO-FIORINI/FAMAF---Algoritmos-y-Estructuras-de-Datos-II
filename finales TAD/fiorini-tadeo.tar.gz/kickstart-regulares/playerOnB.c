#include "playerOnB.h"

#include <assert.h>
#include <stdio.h>
#include <stdlib.h>

struct _node
{
    struct _node* next;
    type_t e;
};

struct _PlayerOnB
{
    struct _node* head;
    Position pos;
    unsigned int points;
};


static struct _node* create_node(type_t e)
{
    struct _node* res = malloc(sizeof(struct _node));
    if (res != NULL)
    {
        res->e = e;
        res->next = NULL;
    }
    return res;
}


static struct _node* destroy_node(struct _node* node)
{
    if (node != NULL)
    {
        free(node);
        node = NULL;
    }
    assert(node == NULL);
    return node;
}

PlayerOnB playerOnB_empty()
{
    PlayerOnB pob = malloc(sizeof(struct _PlayerOnB));
    pob->head = NULL;
    pob->pos = 1;
    pob->points = 0;
    return pob;
}

PlayerOnB playerOnB_add_Road(PlayerOnB pob)
{
    struct _node *new_node = create_node(Road);
    if (pob->head==NULL){
        pob->head = new_node;
    }
    else{
        new_node->next = pob->head;
        pob->head = new_node;
    }
    pob->pos++;
    return pob;
}

PlayerOnB playerOnB_add_Town(PlayerOnB pob)
{
    struct _node *new_node = create_node(Town);
    if (pob->head==NULL){
        pob->head = new_node;
    }
    else{
        new_node->next = pob->head;
        pob->head = new_node;
    }
    pob->pos++;
    pob->points++;
    return pob;    
}

/* MODIFICADORES */

PlayerOnB playerOnB_upgrade_town(PlayerOnB pob, Position pos)
{
    if (pos <= pob->pos){
        struct _node *curr = pob->head;
        struct _node *prev = NULL;
        for (Position p=1; p < pos; ++p){
            prev = curr;
            curr = curr->next;
        }
        if (prev==NULL && curr->e==Town){
            struct _node *new_node = create_node(City); 
            new_node->next = curr->next;
            pob->head = new_node;
            curr = destroy_node(curr);
            pob->points++;
        }
        else if (prev!=NULL && curr->e==Town){
            struct _node *new_node = create_node(City); 
            prev->next = new_node;
            new_node->next = curr->next;
            curr = destroy_node(curr);
            pob->points++;
        }
    }
    return pob;
}

bool playerOnB_is_valid(PlayerOnB pob)
{
    bool valid = true;
    if (pob->head!=NULL){
        struct _node *curr = pob->head;
        struct _node *prev = NULL;
        Position count = 1;
        while (curr->next!=NULL){
            prev = curr;
            curr = curr->next;
            if (playerOnB_size(pob)>=count+2 && prev->e!=Road){
                valid &= curr->e==Road && curr->next->e==Road;
                curr = curr->next;
                count++;
            }
            count++;
        }
    }
    return valid;
}

unsigned int playerOnB_get_score(PlayerOnB pob)
{
    unsigned int points = 0;
    if (playerOnB_is_valid(pob)){
        points = pob->points;
    }
    return points;
}

unsigned int playerOnB_size(PlayerOnB pob)
{
    return pob->pos-1;
}

void playerOnB_print(PlayerOnB pob)
{
    struct _node *curr = pob->head;
    while (curr!=NULL){
        if (curr->e==Road){
            printf(" %c",'R');
        }
        else if (curr->e==Town){
            printf(" %c",'T');
        }
        else if (curr->e==City){
            printf(" %c", 'C');
        }
        curr = curr->next;
    }
}

type_t* playerOnB_array(PlayerOnB pob)
{
    type_t *array = NULL;
    if (pob->head!=NULL){
        array = calloc(playerOnB_size(pob),sizeof(type_t));
        struct _node *curr = pob->head;
        for (Position p=0; p<playerOnB_size(pob); ++p){
            array[p] = curr->e;
            curr = curr->next;
        }
    }
    return array;
}

PlayerOnB playerOnB_destroy(PlayerOnB pob)
{
    if (pob!=NULL){
        struct _node *curr = pob->head;
        while (curr!=NULL){
            struct _node *killme = curr;
            curr = curr->next;
            killme = destroy_node(killme);
        }
        free(pob);
        pob = NULL;
    }
    return pob;
}