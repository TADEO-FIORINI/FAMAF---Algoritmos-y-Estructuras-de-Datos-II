#include <stdio.h>
#include <stdlib.h>

#include "playerOnB.h"

void print_array(type_t *array,Position size){
    printf("[");
    for (Position p=0; p<size; ++p){
        if (array[p]==Road){
            printf(" %c",'R');
        }
        else if (array[p]==Town){
            printf(" %c",'T');
        }
        else if (array[p]==City){
            printf(" %c", 'C');
        }
    }
    printf(" ]");
}

static void test_case1()
{
    printf("TEST CASE 1:\n");
    PlayerOnB pob = playerOnB_empty();
    pob = playerOnB_add_Town(pob);
    pob = playerOnB_add_Road(pob);
    pob = playerOnB_add_Road(pob);
    pob = playerOnB_add_Town(pob);
    pob = playerOnB_upgrade_town(pob,4);
    pob = playerOnB_add_Road(pob);
    pob = playerOnB_add_Road(pob);
    pob = playerOnB_add_Town(pob);
    pob = playerOnB_add_Road(pob);
    pob = playerOnB_add_Town(pob);
    playerOnB_print(pob);
    type_t *array = playerOnB_array(pob);
    printf("\nArray: ");
    print_array(array,playerOnB_size(pob));
    printf("\nSize: %u",playerOnB_size(pob));
    printf("\nValid: ");
    if (playerOnB_is_valid(pob)){
        printf("True");
    }
    else{
        printf("False");
    }
    printf("\nPoints: %u",playerOnB_get_score(pob));
    free(array);
    pob = playerOnB_destroy(pob);
}

static void test_case2()
{
    printf("\n\nTEST CASE 2:\n");
    PlayerOnB pob = playerOnB_empty();
    pob = playerOnB_add_Town(pob);
    pob = playerOnB_add_Road(pob);
    pob = playerOnB_add_Road(pob);
    pob = playerOnB_add_Town(pob);
    pob = playerOnB_add_Road(pob);
    pob = playerOnB_add_Road(pob);
    pob = playerOnB_add_Town(pob);
    pob = playerOnB_upgrade_town(pob,1);
    pob = playerOnB_upgrade_town(pob,4);
    playerOnB_print(pob);
    type_t *array = playerOnB_array(pob);
    printf("\nArray: ");
    print_array(array,playerOnB_size(pob));
    printf("\nSize: %u",playerOnB_size(pob));
    printf("\nValid: ");
    if (playerOnB_is_valid(pob)){
        printf("True");
    }
    else{
        printf("False");
    }
    printf("\nPoints: %u",playerOnB_get_score(pob));
    free(array);
    pob = playerOnB_destroy(pob);
}

static void test_case3()
{
    printf("\n\nTEST CASE 3:\n");
    PlayerOnB pob = playerOnB_empty();
    pob = playerOnB_add_Road(pob);
    pob = playerOnB_add_Road(pob);
    pob = playerOnB_add_Road(pob);
    pob = playerOnB_add_Road(pob);
    playerOnB_print(pob);
    type_t *array = playerOnB_array(pob);
    printf("\nArray: ");
    print_array(array,playerOnB_size(pob));
    printf("\nSize: %u",playerOnB_size(pob));
    printf("\nValid: ");
    if (playerOnB_is_valid(pob)){
        printf("True");
    }
    else{
        printf("False");
    }
    printf("\nPoints: %u",playerOnB_get_score(pob));
    free(array);
    pob = playerOnB_destroy(pob);
}

static void test_case4()
{
    printf("\n\nTEST CASE 4:\n");
    PlayerOnB pob = playerOnB_empty();
    pob = playerOnB_add_Town(pob);
    pob = playerOnB_add_Road(pob);
    pob = playerOnB_add_Road(pob);
    pob = playerOnB_add_Town(pob);
    pob = playerOnB_add_Road(pob);
    pob = playerOnB_add_Road(pob);
    pob = playerOnB_add_Town(pob);
    pob = playerOnB_add_Road(pob);
    pob = playerOnB_add_Town(pob);
    pob = playerOnB_upgrade_town(pob,1);
    pob = playerOnB_upgrade_town(pob,3);
    pob = playerOnB_upgrade_town(pob,6);
    playerOnB_print(pob);
    type_t *array = playerOnB_array(pob);
    printf("\nArray: ");
    print_array(array,playerOnB_size(pob));
    printf("\nSize: %u",playerOnB_size(pob));
    printf("\nValid: ");
    if (playerOnB_is_valid(pob)){
        printf("True");
    }
    else{
        printf("False");
    }
    printf("\nPoints: %u",playerOnB_get_score(pob));
    free(array);
    pob = playerOnB_destroy(pob);
}

static void test_case5()
{
    printf("\n\nTEST CASE 5:\n");
    PlayerOnB pob = playerOnB_empty();
    pob = playerOnB_add_Town(pob);
    pob = playerOnB_upgrade_town(pob,1);
    playerOnB_print(pob);
    type_t *array = playerOnB_array(pob);
    printf("\nArray: ");
    print_array(array,playerOnB_size(pob));
    printf("\nSize: %u",playerOnB_size(pob));
    printf("\nValid: ");
    if (playerOnB_is_valid(pob)){
        printf("True");
    }
    else{
        printf("False");
    }
    printf("\nPoints: %u",playerOnB_get_score(pob));
    free(array);
    pob = playerOnB_destroy(pob);
}

int main(void)
{
    test_case1();
    test_case2();
    test_case3();
    test_case4();
    test_case5();
    printf("\n\n");
    return EXIT_SUCCESS;
}
